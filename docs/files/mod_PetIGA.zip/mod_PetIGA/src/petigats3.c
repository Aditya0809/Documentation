#include "petiga.h"


PetscErrorCode IGATSFormRHSFunction(TS ts,PetscReal t,Vec U,Vec F,void *ctx)
{
  IGA            iga = (IGA)ctx;
  PetscReal      dt;
  PetscReal      a=0;
  PetscReal      t0;
  Vec            U0;
  PetscErrorCode ierr;

  PetscFunctionBegin;
  PetscValidHeaderSpecific(ts,TS_CLASSID,1);
  PetscValidHeaderSpecific(U,VEC_CLASSID,3);
  PetscValidHeaderSpecific(F,VEC_CLASSID,4);
  PetscValidHeaderSpecific(iga,IGA_CLASSID,5);

  ierr = TSGetTimeStep(ts,&dt);CHKERRQ(ierr);
  ierr = IGAComputeRHSFunction(iga,t,U,F);CHKERRQ(ierr);

  PetscFunctionReturn(0);
}

PetscErrorCode IGATSFormRHSJacobian(TS ts,PetscReal t,Vec U,Mat J,Mat P,void *ctx)
{
  IGA            iga = (IGA)ctx;
  PetscReal      dt;
  PetscReal      t0;
  Vec            U0;
  PetscErrorCode ierr;

  PetscFunctionBegin;
  PetscValidHeaderSpecific(ts,TS_CLASSID,1);
  PetscValidHeaderSpecific(U,VEC_CLASSID,3);
  PetscValidHeaderSpecific(J,MAT_CLASSID,4);
  PetscValidHeaderSpecific(P,MAT_CLASSID,5);
  PetscValidHeaderSpecific(iga,IGA_CLASSID,6);

  ierr = TSGetTimeStep(ts,&dt);CHKERRQ(ierr);
  ierr = IGAComputeRHSJacobian(iga,t,U,P);CHKERRQ(ierr);
  
  if (J != P) {
    ierr = MatAssemblyBegin(J,MAT_FINAL_ASSEMBLY);CHKERRQ(ierr);
    ierr = MatAssemblyEnd(J,MAT_FINAL_ASSEMBLY);CHKERRQ(ierr);
  }
  PetscFunctionReturn(0);
}

PetscErrorCode TSSetIGA3(TS ts,IGA iga)
{
  DM             dm;
  Vec            vec;
  PetscErrorCode ierr;

  PetscFunctionBegin;
  PetscValidHeaderSpecific(ts,TS_CLASSID,1);
  PetscValidHeaderSpecific(iga,IGA_CLASSID,2);
  PetscCheckSameComm(ts,1,iga,2);
  ierr = PetscObjectCompose((PetscObject)ts,"IGA",(PetscObject)iga);CHKERRQ(ierr);
  ierr = IGASetOptionsHandlerTS(ts);CHKERRQ(ierr);

  ierr = DMIGACreate(iga,&dm);CHKERRQ(ierr);
  ierr = DMTSSetRHSFunction(dm,IGATSFormRHSFunction,iga);CHKERRQ(ierr);
  ierr = DMTSSetRHSJacobian(dm,IGATSFormRHSJacobian,iga);CHKERRQ(ierr);
  ierr = TSSetDM(ts,dm);CHKERRQ(ierr);
  ierr = DMCreateGlobalVector(dm,&vec);CHKERRQ(ierr);
  ierr = TSSetSolution(ts,vec);CHKERRQ(ierr);
  ierr = VecDestroy(&vec);CHKERRQ(ierr);
  ierr = DMDestroy(&dm);CHKERRQ(ierr);

  ierr = TSGetDM(ts,&dm);CHKERRQ(ierr);
  PetscFunctionReturn(0);
}


/*@
   IGACreateTS - Creates a TS (time stepper) which uses the same
   communicators as the IGA.

   Logically collective on IGA

   Input Parameter:
.  iga - the IGA context

   Output Parameter:
.  ts - the TS

   Level: normal

.keywords: IGA, create, TS
@*/
PetscErrorCode IGACreateTS3(IGA iga,TS *ts)
{
  MPI_Comm       comm;
  Vec            U;
  Vec            F;
  Mat            J;
  PetscErrorCode ierr;

  PetscFunctionBegin;
  PetscValidHeaderSpecific(iga,IGA_CLASSID,1);
  PetscValidPointer(ts,2);

  ierr = IGAGetComm(iga,&comm);CHKERRQ(ierr);
  ierr = TSCreate(comm,ts);CHKERRQ(ierr);
  ierr = PetscObjectCompose((PetscObject)*ts,"IGA",(PetscObject)iga);CHKERRQ(ierr);
  ierr = IGASetOptionsHandlerTS(*ts);CHKERRQ(ierr);

  ierr = IGACreateVec(iga,&U);CHKERRQ(ierr);
  ierr = TSSetSolution(*ts,U);CHKERRQ(ierr);
  ierr = VecDestroy(&U);CHKERRQ(ierr);

  ierr = IGACreateVec(iga,&F);CHKERRQ(ierr);
  ierr = TSSetRHSFunction(*ts,F,IGATSFormRHSFunction,iga);CHKERRQ(ierr);
  ierr = VecDestroy(&F);CHKERRQ(ierr);

  /*ierr = IGACreateMat(iga,&J);CHKERRQ(ierr);
  ierr = TSSetRHSJacobian(*ts,J,J,IGATSFormRHSJacobian,iga);CHKERRQ(ierr);
  ierr = MatDestroy(&J);CHKERRQ(ierr);*/

  PetscFunctionReturn(0);
}
