======
PetIGA
======

:Authors:      Lisandro Dalcin, Nathaniel Collier
:Contact:      dalcinl@gmail.com, nathaniel.collier@gmail.com
:Organization: CONICET_, KAUST_
:Date:         |today|

.. include:: abstract.txt

Contents
========

.. include:: toctree.txt

.. include:: links.txt

Index
=====

* :ref:`genindex`
* :ref:`search`

.. Local Variables:
.. mode: rst
.. End:
