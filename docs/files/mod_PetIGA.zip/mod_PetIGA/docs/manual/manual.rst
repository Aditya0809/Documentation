======
PetIGA
======

.. include:: abstract.txt

.. include:: toctree.txt

.. include:: links.txt

.. Local Variables:
.. mode: rst
.. End:
